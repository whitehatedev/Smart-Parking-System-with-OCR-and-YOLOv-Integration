import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.1/firebase-app.js";
import { getDatabase, ref, onValue, set, update, get } from "https://www.gstatic.com/firebasejs/9.22.1/firebase-database.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyDxylltNCIocdn_6w_XRKp2GOOBwMLieDY",
    authDomain: "smart-parking-system-8fdbd.firebaseapp.com",
    databaseURL: "https://smart-parking-system-8fdbd-default-rtdb.firebaseio.com",
    projectId: "smart-parking-system-8fdbd",
    storageBucket: "smart-parking-system-8fdbd.firebasestorage.app",
    messagingSenderId: "310804168417",
    appId: "1:310804168417:web:5748030e62e3d5608fc1a0"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

// Initialize Firebase real-time listeners
export function initializeFirebase(parkingData, updateParkingDisplay, updateSlotOptions, systemStatus) {
    const slotsRef = ref(database, 'parkingSlots');
    const bookingsRef = ref(database, 'bookings');
    const systemRef = ref(database, 'system');

    onValue(slotsRef, (snapshot) => {
        const data = snapshot.val();
        if (data) {
            Object.keys(data).forEach(slotId => {
                if (parkingData[slotId]) {
                    const hasActiveReservation = parkingData[slotId].bookedUntil &&
                                                 new Date(parkingData[slotId].bookedUntil) > new Date();

                    parkingData[slotId] = {
                        ...parkingData[slotId],
                        ...data[slotId],
                        status: (hasActiveReservation && data[slotId].status !== 'occupied') ? 'reserved' : data[slotId].status
                    };

                    parkingData[slotId].sensorStatus = 'online';
                }
            });

            updateParkingDisplay();
            updateSlotOptions();
            systemStatus.textContent = 'Connected to parking sensors';
            systemStatus.className = 'system-status connected';
        }
    }, (error) => {
        console.error('Firebase slots error:', error);
        systemStatus.textContent = 'Disconnected from sensors';
        systemStatus.className = 'system-status disconnected';

        Object.keys(parkingData).forEach(slotId => {
            parkingData[slotId].sensorStatus = 'offline';
        });
        updateParkingDisplay();
    });

    onValue(bookingsRef, (snapshot) => {
        const data = snapshot.val();
        if (data) {
            Object.keys(data).forEach(bookingId => {
                const booking = data[bookingId];
                if (booking.status === 'active' && parkingData[booking.slot]) {
                    parkingData[booking.slot].bookedUntil = booking.bookedUntil;
                    parkingData[booking.slot].carNumber = booking.carNumber;
                    parkingData[booking.slot].carType = booking.carType;
                    parkingData[booking.slot].bookingStart = booking.bookedAt;

                    const now = new Date();
                    const bookedUntil = new Date(booking.bookedUntil);
                    if (bookedUntil > now) {
                        if (parkingData[booking.slot].status !== 'occupied') {
                            parkingData[booking.slot].status = 'reserved';
                        }
                    } else {
                        if (parkingData[booking.slot].status === 'reserved') {
                            parkingData[booking.slot].status = 'available';
                            parkingData[booking.slot].carNumber = '';
                            parkingData[booking.slot].carType = '';
                            parkingData[booking.slot].bookedUntil = null;
                        }
                    }
                }
            });
            updateParkingDisplay();
            updateSlotOptions();
        }
    });

    onValue(systemRef, (snapshot) => {
        const data = snapshot.val();
        if (data) {
            // Update system status if needed
        }
    });

    loadInitialData(parkingData, updateParkingDisplay, updateSlotOptions);
}

// Load initial data from Firebase
export async function loadInitialData(parkingData, updateParkingDisplay, updateSlotOptions) {
    try {
        const slotsSnapshot = await get(ref(database, 'parkingSlots'));
        const bookingsSnapshot = await get(ref(database, 'bookings'));

        if (slotsSnapshot.exists()) {
            const slotsData = slotsSnapshot.val();
            Object.keys(slotsData).forEach(slotId => {
                if (parkingData[slotId]) {
                    parkingData[slotId] = { ...parkingData[slotId], ...slotsData[slotId] };
                }
            });
        }

        if (bookingsSnapshot.exists()) {
            const bookingsData = bookingsSnapshot.val();
            Object.keys(bookingsData).forEach(bookingId => {
                const booking = bookingsData[bookingId];
                if (booking.status === 'active' && parkingData[booking.slot]) {
                    parkingData[booking.slot].bookedUntil = booking.bookedUntil;
                    parkingData[booking.slot].carNumber = booking.carNumber;
                    parkingData[booking.slot].carType = booking.carType;
                    parkingData[booking.slot].bookingStart = booking.bookedAt;

                    const now = new Date();
                    const bookedUntil = new Date(booking.bookedUntil);
                    if (bookedUntil > now && parkingData[booking.slot].status !== 'occupied') {
                        parkingData[booking.slot].status = 'reserved';
                    }
                }
            });
        }

        updateParkingDisplay();
        updateSlotOptions();
        console.log('Initial data loaded successfully');
    } catch (error) {
        console.error('Error loading initial data:', error);
    }
}

// Update Firebase with booking information
export function updateFirebaseWithBooking(slotId, duration, bookingId, carNumber, carType, phone, email) {
    const now = new Date();
    let endTime = new Date(now);

    if (duration.includes('hour')) {
        const hours = parseInt(duration) || 1;
        endTime.setHours(now.getHours() + hours);
    } else {
        endTime.setHours(now.getHours() + 2);
    }

    const slotRef = ref(database, `parkingSlots/${slotId}`);
    update(slotRef, {
        status: 'reserved',
        bookedUntil: endTime.toISOString(),
        bookingId: bookingId,
        carNumber: carNumber,
        carType: carType
    });

    const bookingRef = ref(database, `bookings/${bookingId}`);
    set(bookingRef, {
        slot: slotId,
        carNumber: carNumber,
        carType: carType,
        phone: phone,
        email: email,
        duration: duration,
        bookedAt: now.toISOString(),
        bookedUntil: endTime.toISOString(),
        status: 'active'
    });

    console.log(`Booking ${bookingId} created for ${slotId}`);
}