// Camera state
let currentStream = null;
let currentCamera = 'front';

// DOM Elements
const cameraView = document.getElementById('cameraView');
const detectionCanvas = document.getElementById('detectionCanvas');
const frontCameraBtn = document.getElementById('frontCameraBtn');
const backCameraBtn = document.getElementById('backCameraBtn');
const captureBtn = document.getElementById('captureBtn');
const detectionLoading = document.getElementById('detectionLoading');
const detectionResult = document.getElementById('detectionResult');
const carNumber = document.getElementById('carNumber');

// Initialize camera
export async function initCamera(cameraType = 'front') {
    try {
        // Stop any existing stream
        if (currentStream) {
            currentStream.getTracks().forEach(track => track.stop());
        }

        // Get camera constraints
        const constraints = {
            video: {
                facingMode: cameraType === 'front' ? 'user' : 'environment',
                width: { ideal: 640 },
                height: { ideal: 480 }
            },
            audio: false
        };

        // Get camera stream
        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        cameraView.srcObject = stream;
        cameraView.style.display = 'block';
        currentStream = stream;
        currentCamera = cameraType;

        // Update button states
        if (cameraType === 'front') {
            frontCameraBtn.classList.add('active');
            backCameraBtn.classList.remove('active');
        } else {
            backCameraBtn.classList.add('active');
            frontCameraBtn.classList.remove('active');
        }

        console.log(`Camera initialized: ${cameraType}`);
    } catch (error) {
        console.error('Error initializing camera:', error);
        detectionResult.textContent = 'Camera access denied. Please allow camera permissions.';
        detectionResult.className = 'detection-result error';
    }
}

// Capture image and detect number plate
export async function captureAndDetect() {
    if (!currentStream) {
        detectionResult.textContent = 'Please initialize camera first';
        detectionResult.className = 'detection-result error';
        return;
    }

    try {
        // Show loading indicator
        detectionLoading.style.display = 'block';
        detectionResult.textContent = '';
        detectionResult.className = 'detection-result';

        // Draw video frame to canvas
        const context = detectionCanvas.getContext('2d');
        detectionCanvas.width = cameraView.videoWidth;
        detectionCanvas.height = cameraView.videoHeight;
        context.drawImage(cameraView, 0, 0, detectionCanvas.width, detectionCanvas.height);

        // Use Tesseract.js for OCR
        const result = await Tesseract.recognize(
            detectionCanvas,
            'eng',
            {
                logger: m => console.log(m),
                tessedit_char_whitelist: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
            }
        );

        // Process OCR result to find number plate
        const detectedText = result.data.text;
        const numberPlate = extractNumberPlate(detectedText);

        // Hide loading indicator
        detectionLoading.style.display = 'none';

        if (numberPlate) {
            carNumber.value = numberPlate;
            detectionResult.textContent = `Detected: ${numberPlate}`;
            detectionResult.className = 'detection-result success';
        } else {
            detectionResult.textContent = 'No number plate detected. Please try again or enter manually.';
            detectionResult.className = 'detection-result error';
        }
    } catch (error) {
        console.error('Error in number plate detection:', error);
        detectionLoading.style.display = 'none';
        detectionResult.textContent = 'Detection failed. Please try again or enter manually.';
        detectionResult.className = 'detection-result error';
    }
}

// Extract number plate from OCR text
function extractNumberPlate(text) {
    // Clean up the text
    const cleanedText = text.replace(/\s+/g, '').toUpperCase();

    // Common number plate patterns
    const patterns = [
        /[A-Z]{2}\d{2}[A-Z]{2}\d{4}/, // Indian format: AB12CD3456
        /[A-Z]{3}\d{4}/, // US format: ABC1234
        /[A-Z]{2}\d{6}/, // Alternative format
        /[A-Z]{1,2}\d{1,4}[A-Z]{1,3}/, // Flexible format
    ];

    for (const pattern of patterns) {
        const match = cleanedText.match(pattern);
        if (match) {
            return match[0];
        }
    }

    // If no pattern matches, try to extract alphanumeric sequences
    const alphanumeric = cleanedText.match(/[A-Z0-9]{4,10}/g);
    if (alphanumeric && alphanumeric.length > 0) {
        return alphanumeric.reduce((a, b) => a.length > b.length ? a : b);
    }

    return null;
}

// Set up camera controls
document.addEventListener('DOMContentLoaded', () => {
    frontCameraBtn.addEventListener('click', () => initCamera('front'));
    backCameraBtn.addEventListener('click', () => initCamera('back'));
    captureBtn.addEventListener('click', captureAndDetect);
});