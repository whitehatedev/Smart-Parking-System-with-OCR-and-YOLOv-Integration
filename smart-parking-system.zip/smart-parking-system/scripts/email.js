// EmailJS configuration
emailjs.init("Lq_iTKNwNjlO_5D5s");

// Email notification system
export const emailNotifier = {
    config: {
        serviceId: 'service_hd8oswg',
        bookingTemplateId: 'template_booking_confirmation',
        alertTemplateId: 'template_alert_notification',
        welcomeTemplateId: 'template_welcome_email'
    },
    registeredCustomers: new Map(),
    alertInterval: null,
    isInitialized: false,

    async init() {
        try {
            this.isInitialized = true;
            this.updateEmailStatus('Email service initialized successfully', 'success');
            this.startAlertSystem();
            return true;
        } catch (error) {
            this.updateEmailStatus('Failed to initialize email service: ' + error.message, 'error');
            return false;
        }
    },

    registerCustomer(email, phone, name = '') {
        const customerId = 'CUST_' + Math.random().toString(36).substr(2, 9).toUpperCase();
        this.registeredCustomers.set(customerId, {
            email: email,
            phone: phone,
            name: name,
            registrationDate: new Date(),
            alertsEnabled: true,
            preferences: {
                bookingConfirmations: true,
                overtimeAlerts: true,
                systemAlerts: true,
                promotional: false
            }
        });

        console.log(`Customer registered: ${email}`);
        this.updateEmailStatus(`Customer ${email} registered for notifications`);

        this.sendWelcomeEmail(email, name);

        return customerId;
    },

    async sendWelcomeEmail(email, name) {
        try {
            const templateParams = {
                to_email: email,
                to_name: name || 'Valued Customer',
                welcome_message: 'Welcome to Smart Parking System!',
                registration_date: new Date().toLocaleDateString(),
                from_name: 'Smart Parking System'
            };

            await emailjs.send(
                this.config.serviceId,
                this.config.welcomeTemplateId,
                templateParams
            );
            this.updateEmailStatus(`Welcome email sent to ${email}`);
        } catch (error) {
            console.log('Welcome email not sent (template might not exist):', error.message);
        }
    },

    async sendBookingConfirmation(bookingData) {
        if (!this.isInitialized) {
            this.updateEmailStatus('Email service not initialized', 'error');
            return false;
        }

        try {
            const templateParams = {
                to_email: bookingData.email,
                to_name: bookingData.name || 'Valued Customer',
                car_number: bookingData.carNumber,
                car_type: this.formatCarType(bookingData.carType),
                parking_slot: bookingData.slot,
                time_duration: bookingData.duration,
                booking_id: bookingData.bookingId,
                booking_date: new Date().toLocaleDateString(),
                booking_time: new Date().toLocaleTimeString(),
                estimated_cost: this.calculateCost(bookingData.duration, bookingData.carType),
                support_contact: 'sb284160@gmail.com',
                from_name: 'Smart Parking System'
            };

            const response = await emailjs.send(
                this.config.serviceId,
                this.config.bookingTemplateId,
                templateParams
            );

            this.updateEmailStatus(`Booking confirmation sent to ${bookingData.email}`, 'success');
            console.log('Booking confirmation email sent successfully:', response);

            this.updateCustomerNotification(bookingData.email);

            return true;
        } catch (error) {
            this.updateEmailStatus(`Failed to send confirmation to ${bookingData.email}: ${error.message}`, 'error');
            console.error('Failed to send booking confirmation:', error);
            return false;
        }
    },

    async sendAlertNotification(alertData) {
        if (!this.isInitialized) {
            return { success: false, error: 'Email system not initialized' };
        }

        let successCount = 0;
        let failCount = 0;

        for (let [customerId, customer] of this.registeredCustomers) {
            if (customer.alertsEnabled && this.shouldSendAlert(customer, alertData.type)) {
                try {
                    const templateParams = {
                        to_email: customer.email,
                        to_name: customer.name || 'Valued Customer',
                        alert_type: alertData.type,
                        alert_severity: alertData.severity || 'medium',
                        alert_message: alertData.message,
                        alert_time: new Date().toLocaleString(),
                        parking_slot: alertData.slot || 'N/A',
                        car_number: alertData.carNumber || 'N/A',
                        recommended_action: alertData.action || 'No action required',
                        from_name: 'Smart Parking System'
                    };

                    await emailjs.send(
                        this.config.serviceId,
                        this.config.alertTemplateId,
                        templateParams
                    );

                    successCount++;
                    this.updateEmailStatus(`Alert sent to ${customer.email}`);
                    this.updateCustomerNotification(customer.email);
                } catch (error) {
                    failCount++;
                    console.error(`Failed to send alert to ${customer.email}:`, error);
                }
            }
        }

        this.updateEmailStatus(`Alerts sent: ${successCount} successful, ${failCount} failed`);
        return { successCount, failCount };
    },

    async sendOvertimeAlert(slotId, carNumber, overtimeDuration) {
        const alertData = {
            type: 'Overtime Parking',
            severity: 'high',
            message: `Vehicle ${carNumber} in ${slotId} has exceeded parking time by ${overtimeDuration}`,
            slot: slotId,
            carNumber: carNumber,
            action: 'Please move your vehicle or extend your parking time to avoid additional charges.'
        };

        return await this.sendAlertNotification(alertData);
    },

    startAlertSystem() {
        if (this.alertInterval) {
            clearInterval(this.alertInterval);
        }

        this.alertInterval = setInterval(() => {
            this.sendPeriodicAlerts();
        }, 5 * 60 * 1000);

        this.updateEmailStatus('Alert system started - sending notifications every 5 minutes', 'success');
        console.log('Alert system started - sending notifications every 5 minutes');
    },

    stopAlertSystem() {
        if (this.alertInterval) {
            clearInterval(this.alertInterval);
            this.alertInterval = null;
            this.updateEmailStatus('Alert system stopped');
            console.log('Alert system stopped');
        }
    },

    async sendPeriodicAlerts() {
        console.log('Sending periodic system alerts...');
        this.updateEmailStatus('Sending periodic alerts to registered customers...');

        try {
            const systemStatus = this.getSystemStatus();
            await this.sendSystemStatusAlert(systemStatus);
            await this.checkAndSendOvertimeAlerts();
            this.updateEmailStatus('Periodic alerts sent successfully');
        } catch (error) {
            this.updateEmailStatus('Error sending periodic alerts: ' + error.message, 'error');
        }
    },

    async sendSystemStatusAlert(systemStatus) {
        const message = `System Status Update:
• Total Slots: ${systemStatus.totalSlots}
• Available: ${systemStatus.availableSlots}
• Occupied: ${systemStatus.occupiedSlots}
• Reserved: ${systemStatus.reservedSlots}
• Last Update: ${new Date(systemStatus.lastUpdate).toLocaleString()}`;

        const alertData = {
            type: 'System Status Update',
            severity: 'low',
            message: message,
            action: 'System operating normally.'
        };

        return await this.sendAlertNotification(alertData);
    },

    async checkAndSendOvertimeAlerts() {
        const parkingData = this.getCurrentParkingStatus();
        const now = new Date();

        for (const [slotId, slot] of Object.entries(parkingData)) {
            if (slot.status === 'occupied' && slot.bookedUntil) {
                const bookedUntil = new Date(slot.bookedUntil);
                if (now > bookedUntil) {
                    const overtimeMs = now - bookedUntil;
                    const overtimeMinutes = Math.floor(overtimeMs / (1000 * 60));
                    const overtimeHours = Math.floor(overtimeMinutes / 60);

                    let overtimeDuration;
                    if (overtimeHours > 0) {
                        overtimeDuration = `${overtimeHours}h ${overtimeMinutes % 60}m`;
                    } else {
                        overtimeDuration = `${overtimeMinutes}m`;
                    }

                    await this.sendOvertimeAlert(slotId, slot.carNumber, overtimeDuration);
                }
            }
        }
    },

    getSystemStatus() {
        const parkingData = this.getCurrentParkingStatus();
        return {
            totalSlots: 4,
            availableSlots: Object.values(parkingData).filter(slot =>
                slot.status === 'available' || slot.status === 'unknown'
            ).length,
            occupiedSlots: Object.values(parkingData).filter(slot =>
                slot.status === 'occupied'
            ).length,
            reservedSlots: Object.values(parkingData).filter(slot =>
                slot.status === 'reserved'
            ).length,
            lastUpdate: new Date().toISOString()
        };
    },

    getCurrentParkingStatus() {
        return window.parkingData || {};
    },

    formatCarType(carType) {
        const types = {
            'private': 'Private Vehicle',
            'ev': 'Electric Vehicle',
            'commercial': 'Commercial Vehicle'
        };
        return types[carType] || carType;
    },

    calculateCost(duration, carType) {
        const rates = {
            'private': 2,
            'ev': 3,
            'commercial': 5
        };
        const baseRate = rates[carType] || 2;
        const hours = this.parseDuration(duration);
        return `$${(baseRate * hours).toFixed(2)}`;
    },

    parseDuration(duration) {
        const hoursMatch = duration.match(/(\d+)\s*hour/);
        return hoursMatch ? parseInt(hoursMatch[1]) : 2;
    },

    shouldSendAlert(customer, alertType) {
        const preferences = customer.preferences;
        switch (alertType) {
            case 'Overtime Parking':
                return preferences.overtimeAlerts;
            case 'System Maintenance':
            case 'System Status Update':
                return preferences.systemAlerts;
            case 'Special Offer':
                return preferences.promotional;
            case 'Parking Slot Available':
            case 'Booking Confirmation':
                return preferences.bookingConfirmations;
            default:
                return true;
        }
    },

    updateCustomerNotification(email) {
        for (let [customerId, customer] of this.registeredCustomers) {
            if (customer.email === email) {
                customer.lastNotification = new Date();
                break;
            }
        }
    },

    updateEmailStatus(message, type = '') {
        const emailStatusDisplay = document.getElementById('emailStatusDisplay');
        if (!emailStatusDisplay) return;

        emailStatusDisplay.textContent = message;
        emailStatusDisplay.style.display = 'block';
        emailStatusDisplay.className = 'email-status';

        if (type === 'success') {
            emailStatusDisplay.classList.add('success');
        } else if (type === 'error') {
            emailStatusDisplay.classList.add('error');
        }

        const emailStatus = document.getElementById('emailStatus');
        if (emailStatus) {
            emailStatus.textContent = `Email Service: ${type === 'error' ? 'Error' : 'Active'}`;
        }

        if (type !== 'error') {
            setTimeout(() => {
                if (emailStatusDisplay) {
                    emailStatusDisplay.style.display = 'none';
                }
            }, 5000);
        }
    },

    getRegisteredCustomers() {
        return Array.from(this.registeredCustomers.values());
    }
};