// Main application controller
import { initializeFirebase, updateFirebaseWithBooking, loadInitialData } from './firebase.js';
import { emailNotifier } from './email.js';
import { initCamera, captureAndDetect } from './camera.js';

// DOM Elements
const steps = document.querySelectorAll('.step');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const bookBtn = document.getElementById('bookBtn');
const newBookingBtn = document.getElementById('newBookingBtn');
const confirmation = document.getElementById('confirmation');
const slotsContainer = document.getElementById('slotsContainer');
const slotOptions = document.getElementById('slotOptions');
const carTypeOptions = document.getElementById('carTypeOptions');
const systemStatus = document.getElementById('systemStatus');
const notificationStatus = document.getElementById('notificationStatus');
const smsStatus = document.getElementById('smsStatus');
const alertStatus = document.getElementById('alertStatus');
const emailStatus = document.getElementById('emailStatus');
const alertSound = document.getElementById('alertSound');
const emailStatusDisplay = document.getElementById('emailStatusDisplay');

// Form fields
const carNumber = document.getElementById('carNumber');
const phoneNumber = document.getElementById('phoneNumber');
const emailInput = document.getElementById('email');
const timeDuration = document.getElementById('timeDuration');

// Voice feedback elements
const feedbacks = [
    document.getElementById('feedback1'),
    document.getElementById('feedback2'),
    document.getElementById('feedback3'),
    document.getElementById('feedback4'),
    document.getElementById('feedback5'),
    document.getElementById('feedback6')
];

// Confirmation elements
const confirmCarNumber = document.getElementById('confirmCarNumber');
const confirmCarType = document.getElementById('confirmCarType');
const confirmPhone = document.getElementById('confirmPhone');
const confirmEmail = document.getElementById('confirmEmail');
const confirmSlot = document.getElementById('confirmSlot');
const confirmDuration = document.getElementById('confirmDuration');
const confirmBookingId = document.getElementById('confirmBookingId');

// State variables
let currentStep = 0;
let selectedCarType = '';
let selectedSlot = '';
let parkingData = {
    slot1: { status: 'unknown', distance: 0, bookedUntil: null, carNumber: '', carType: '', bookingStart: null, sensorStatus: 'offline' },
    slot2: { status: 'unknown', distance: 0, bookedUntil: null, carNumber: '', carType: '', bookingStart: null, sensorStatus: 'offline' },
    slot3: { status: 'unknown', distance: 0, bookedUntil: null, carNumber: '', carType: '', bookingStart: null, sensorStatus: 'offline' },
    slot4: { status: 'unknown', distance: 0, bookedUntil: null, carNumber: '', carType: '', bookingStart: null, sensorStatus: 'offline' }
};
let alertPlayed = false;
let countdownInterval;
let lastAlertTime = 0;
const ALERT_COOLDOWN = 10000; // 10 seconds cooldown between alerts

// Initialize Speech Recognition
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition;

if (SpeechRecognition) {
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = function() {
        console.log('Speech recognition started');
    };

    recognition.onresult = function(event) {
        const transcript = event.results[0][0].transcript.toLowerCase().trim();
        console.log('Speech recognized:', transcript);
        processVoiceCommand(transcript);
    };

    recognition.onerror = function(event) {
        console.error('Speech recognition error:', event.error);
        updateFeedback(currentStep, `Error: ${event.error}. Please try again.`);
    };

    recognition.onend = function() {
        console.log('Speech recognition ended');
        document.querySelectorAll('.mic-btn').forEach(btn => {
            btn.classList.remove('listening');
        });
    };
} else {
    console.warn('Speech recognition not supported');
}

// Initialize the app
export async function initApp() {
    // Set up event listeners for mic buttons
    document.querySelectorAll('.mic-btn').forEach((btn, index) => {
        btn.addEventListener('click', () => {
            startListening(index);
        });
    });

    // Set up event listeners for car type options
    carTypeOptions.querySelectorAll('.option').forEach(option => {
        option.addEventListener('click', () => {
            carTypeOptions.querySelectorAll('.option').forEach(opt => {
                opt.classList.remove('selected');
            });
            option.classList.add('selected');
            selectedCarType = option.dataset.value;
            updateFeedback(1, `Selected: ${option.textContent}`);
        });
    });

    // Set up navigation buttons
    prevBtn.addEventListener('click', goToPreviousStep);
    nextBtn.addEventListener('click', goToNextStep);
    bookBtn.addEventListener('click', confirmBooking);
    newBookingBtn.addEventListener('click', resetForm);

    // Initialize Firebase listeners
    initializeFirebase(parkingData, updateParkingDisplay, updateSlotOptions, systemStatus);

    // Initialize email system
    await emailNotifier.init();

    // Initialize camera
    await initCamera();

    // Load initial data
    await loadInitialData(parkingData, updateParkingDisplay, updateSlotOptions);

    // Show first step
    showStep(currentStep);

    // Start countdown timer
    startCountdownTimer();

    console.log('Smart Parking System initialized successfully');
}

// Start countdown timer for time displays
function startCountdownTimer() {
    if (countdownInterval) {
        clearInterval(countdownInterval);
    }

    countdownInterval = setInterval(() => {
        updateTimeDisplays();
        checkForAlerts();
    }, 1000);
}

// Update time displays for all slots
function updateTimeDisplays() {
    Object.keys(parkingData).forEach(slotId => {
        const slot = parkingData[slotId];
        const timeDisplayElement = document.getElementById(`timeDisplay${slotId.charAt(slotId.length-1)}`);
        const timeBreakdownElement = document.getElementById(`timeBreakdown${slotId.charAt(slotId.length-1)}`);

        if (!timeDisplayElement) return;

        if ((slot.status === 'reserved' || slot.status === 'occupied') && slot.bookedUntil) {
            const now = new Date();
            const bookedUntil = new Date(slot.bookedUntil);
            const timeDiff = bookedUntil - now;

            if (timeDiff > 0) {
                const hours = Math.floor(timeDiff / (1000 * 60 * 60));
                const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((timeDiff % (1000 * 60)) / 1000);

                let timeText = '';
                if (hours > 0) {
                    timeText = `Remaining: ${hours}h ${minutes}m ${seconds}s`;
                } else if (minutes > 0) {
                    timeText = `Remaining: ${minutes}m ${seconds}s`;
                } else {
                    timeText = `Remaining: ${seconds}s`;
                }

                timeDisplayElement.textContent = timeText;
                timeDisplayElement.style.display = 'block';
                timeDisplayElement.className = 'time-display remaining-time';

                if (timeDiff < 15 * 60 * 1000) {
                    timeDisplayElement.className = 'time-display free-soon';
                }

                if (timeBreakdownElement) {
                    const totalMinutes = Math.floor(timeDiff / (1000 * 60));
                    timeBreakdownElement.innerHTML = `<div>Booked Time: ${formatTimeDisplay(totalMinutes)}</div>`;
                    timeBreakdownElement.style.display = 'block';
                }
            } else {
                const overtime = Math.abs(timeDiff);
                const hours = Math.floor(overtime / (1000 * 60 * 60));
                const minutes = Math.floor((overtime % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((overtime % (1000 * 60)) / 1000);

                let timeText = '';
                if (hours > 0) {
                    timeText = `OVERTIME: ${hours}h ${minutes}m ${seconds}s`;
                } else if (minutes > 0) {
                    timeText = `OVERTIME: ${minutes}m ${seconds}s`;
                } else {
                    timeText = `OVERTIME: ${seconds}s`;
                }

                timeDisplayElement.textContent = timeText;
                timeDisplayElement.style.display = 'block';
                timeDisplayElement.className = 'time-display overtime-warning';

                if (timeBreakdownElement) {
                    const baseHours = 2;
                    const overtimeHours = hours + (minutes / 60);
                    const extraCharge = calculateOvertimeCharge(overtimeHours);

                    timeBreakdownElement.innerHTML = `
                        <div>Base Time: ${baseHours}h</div>
                        <div>Overtime: ${overtimeHours.toFixed(1)}h</div>
                        <div>Extra Charge: ₹${extraCharge}</div>
                    `;
                    timeBreakdownElement.style.display = 'block';
                }

                triggerOvertimeAlert(slotId, slot.carNumber);
            }
        } else if (slot.status === 'occupied' && !slot.bookedUntil) {
            timeDisplayElement.textContent = 'No Booking - Manual Check Required';
            timeDisplayElement.style.display = 'block';
            timeDisplayElement.className = 'time-display overtime-warning';
        } else {
            timeDisplayElement.style.display = 'none';
            if (timeBreakdownElement) {
                timeBreakdownElement.style.display = 'none';
            }
        }
    });
}

// Calculate overtime charges
function calculateOvertimeCharge(overtimeHours) {
    const baseRate = 50;
    const overtimeRate = baseRate * 1.5;
    return (overtimeHours * overtimeRate).toFixed(2);
}

// Format time display
function formatTimeDisplay(totalMinutes) {
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    if (hours > 0) {
        return `${hours}h ${minutes}m`;
    } else {
        return `${minutes}m`;
    }
}

// Trigger overtime alert
function triggerOvertimeAlert(slotId, carNumber) {
    const now = Date.now();
    if (now - lastAlertTime > ALERT_COOLDOWN) {
        playAlertSound();
        lastAlertTime = now;

        alertStatus.textContent = `ALERT: ${carNumber || 'Vehicle'} overtime in ${slotId}`;
        alertStatus.style.color = '#dc3545';
        alertStatus.style.fontWeight = 'bold';

        const bookedUntil = new Date(parkingData[slotId].bookedUntil);
        const overtimeMs = now - bookedUntil;
        const overtimeMinutes = Math.floor(overtimeMs / (1000 * 60));
        const overtimeHours = Math.floor(overtimeMinutes / 60);

        let overtimeDuration;
        if (overtimeHours > 0) {
            overtimeDuration = `${overtimeHours}h ${overtimeMinutes % 60}m`;
        } else {
            overtimeDuration = `${overtimeMinutes}m`;
        }

        emailNotifier.sendOvertimeAlert(slotId, carNumber, overtimeDuration);
    }
}

// Check for alert conditions
function checkForAlerts() {
    let shouldAlert = false;
    let alertMessage = '';

    Object.keys(parkingData).forEach(slotId => {
        const slot = parkingData[slotId];

        if (slot.status === 'occupied' && (!slot.carNumber || slot.carNumber === '')) {
            shouldAlert = true;
            alertMessage = `Unauthorized vehicle detected in ${slotId}`;
        }

        if (slot.status === 'unknown') {
            shouldAlert = true;
            alertMessage = `Sensor offline for ${slotId}`;
        }
    });

    if (shouldAlert && !alertPlayed) {
        playAlertSound();
        alertPlayed = true;
        alertStatus.textContent = `ALERT: ${alertMessage}`;
        alertStatus.style.color = '#dc3545';

        setTimeout(() => {
            alertPlayed = false;
            alertStatus.textContent = 'Alert System: Active';
            alertStatus.style.color = '';
        }, ALERT_COOLDOWN);
    }
}

// Play alert sound
function playAlertSound() {
    try {
        if (alertSound) {
            alertSound.currentTime = 0;
            alertSound.play().catch(e => {
                console.log('Could not play alert sound:', e);
                createBeepSound();
            });
        } else {
            createBeepSound();
        }
    } catch (error) {
        console.log('Could not play alert sound:', error);
        createBeepSound();
    }
}

// Create beep sound using Web Audio API
function createBeepSound() {
    try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);

        oscillator.frequency.value = 800;
        oscillator.type = 'sine';

        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);

        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.5);
    } catch (error) {
        console.log('Web Audio API not supported');
    }
}

// Update parking slot display
export function updateParkingDisplay() {
    slotsContainer.innerHTML = '';

    Object.keys(parkingData).forEach(slotId => {
        const slot = parkingData[slotId];
        const slotElement = document.createElement('div');
        slotElement.className = `slot ${slot.status}`;
        slotElement.id = slotId;

        slotElement.addEventListener('click', () => {
            if (slot.status === 'available' || slot.status === 'unknown') {
                selectSlotFromDisplay(slotId);
            }
        });

        const slotNumber = document.createElement('div');
        slotNumber.className = 'slot-number';
        slotNumber.textContent = `Slot ${slotId.charAt(slotId.length-1)}`;

        const slotStatus = document.createElement('div');
        slotStatus.className = 'slot-status';

        let statusText = '';
        let timeText = '';

        switch(slot.status) {
            case 'available':
                statusText = 'Available';
                timeText = 'Free';
                break;
            case 'occupied':
                statusText = 'Occupied';
                timeText = slot.carNumber ? `Car: ${slot.carNumber}` : 'In Use (No Booking)';
                break;
            case 'reserved':
                statusText = 'Reserved';
                timeText = slot.carNumber ? `Car: ${slot.carNumber}` : 'Booked';
                break;
            default:
                statusText = 'Unknown';
                timeText = 'Sensor Offline';
        }

        slotStatus.textContent = statusText;

        const slotTime = document.createElement('div');
        slotTime.className = 'slot-time';
        slotTime.textContent = timeText;

        const slotDistance = document.createElement('div');
        slotDistance.className = 'slot-distance';
        slotDistance.textContent = `Distance: ${slot.distance}cm`;

        const sensorStatus = document.createElement('div');
        sensorStatus.className = `sensor-status ${slot.sensorStatus === 'online' ? 'sensor-online' : 'sensor-offline'}`;
        sensorStatus.textContent = `Sensor: ${slot.sensorStatus === 'online' ? 'Online' : 'Offline'}`;

        if (slot.status === 'reserved') {
            const reservationDetails = document.createElement('div');
            reservationDetails.className = 'reservation-details';
            reservationDetails.innerHTML = `
                <div><strong>Reservation Details:</strong></div>
                <div>Car: ${slot.carNumber || 'N/A'}</div>
                <div>Type: ${slot.carType || 'N/A'}</div>
            `;
            slotElement.appendChild(reservationDetails);
        }

        if (slot.status === 'occupied') {
            const vehicleDetails = document.createElement('div');
            vehicleDetails.className = 'vehicle-details';
            vehicleDetails.innerHTML = `
                <div><strong>Vehicle Details:</strong></div>
                <div>Car: ${slot.carNumber || 'N/A'}</div>
                <div>Type: ${slot.carType || 'N/A'}</div>
            `;
            slotElement.appendChild(vehicleDetails);
        }

        const timeDisplay = document.createElement('div');
        timeDisplay.className = 'time-display';
        timeDisplay.id = `timeDisplay${slotId.charAt(slotId.length-1)}`;

        const timeBreakdown = document.createElement('div');
        timeBreakdown.className = 'time-breakdown';
        timeBreakdown.id = `timeBreakdown${slotId.charAt(slotId.length-1)}`;

        slotElement.appendChild(slotNumber);
        slotElement.appendChild(slotStatus);
        slotElement.appendChild(slotTime);
        slotElement.appendChild(slotDistance);
        slotElement.appendChild(sensorStatus);
        slotElement.appendChild(timeDisplay);
        slotElement.appendChild(timeBreakdown);

        slotsContainer.appendChild(slotElement);
    });

    updateTimeDisplays();
}

// Select slot from display click
function selectSlotFromDisplay(slotId) {
    if (currentStep >= 4) {
        slotOptions.querySelectorAll('.option').forEach(opt => {
            opt.classList.remove('selected');
        });

        const option = Array.from(slotOptions.querySelectorAll('.option')).find(
            opt => opt.dataset.value === slotId
        );

        if (option) {
            option.classList.add('selected');
            selectedSlot = slotId;
            updateFeedback(4, `Selected: ${option.textContent}`);

            if (currentStep === 4) {
                goToNextStep();
            }
        }
    }
}

// Update slot options in booking form
export function updateSlotOptions() {
    slotOptions.innerHTML = '';

    Object.keys(parkingData).forEach(slotId => {
        const slot = parkingData[slotId];
        if (slot.status === 'available' || slot.status === 'unknown') {
            const option = document.createElement('div');
            option.className = 'option';
            option.dataset.value = slotId;
            option.textContent = `Slot ${slotId.charAt(slotId.length-1)}`;

            if (slot.status === 'unknown') {
                option.innerHTML += ' <span style="color: #6c757d; font-size: 0.8em;">(Sensor Offline)</span>';
            }

            option.addEventListener('click', () => {
                slotOptions.querySelectorAll('.option').forEach(opt => {
                    opt.classList.remove('selected');
                });
                option.classList.add('selected');
                selectedSlot = slotId;
                updateFeedback(4, `Selected: ${option.textContent}`);
            });

            slotOptions.appendChild(option);
        }
    });

    if (slotOptions.children.length === 0) {
        const message = document.createElement('div');
        message.textContent = 'No available slots at the moment';
        message.style.textAlign = 'center';
        message.style.padding = '15px';
        message.style.color = '#666';
        slotOptions.appendChild(message);
    }
}

// Start listening for voice input
function startListening(stepIndex) {
    if (!recognition) {
        alert('Speech recognition is not supported in your browser.');
        return;
    }

    document.getElementById(`mic${stepIndex + 1}`).classList.add('listening');
    updateFeedback(stepIndex, 'Listening... Speak now');

    try {
        recognition.start();
    } catch (error) {
        console.error('Error starting speech recognition:', error);
    }
}

// Process voice commands
function processVoiceCommand(transcript) {
    if (transcript.includes('next')) {
        goToNextStep();
        return;
    }

    if (transcript.includes('previous')) {
        goToPreviousStep();
        return;
    }

    if (transcript.includes('book')) {
        if (currentStep === 5) {
            confirmBooking();
        } else {
            updateFeedback(currentStep, 'Please complete all steps before booking');
        }
        return;
    }

    switch (currentStep) {
        case 0:
            carNumber.value = transcript.toUpperCase();
            updateFeedback(0, `Car number set to: ${transcript.toUpperCase()}`);
            break;

        case 1:
            if (transcript.includes('private')) {
                selectCarTypeOption('private');
            } else if (transcript.includes('ev') || transcript.includes('electric')) {
                selectCarTypeOption('ev');
            } else if (transcript.includes('commercial')) {
                selectCarTypeOption('commercial');
            } else {
                updateFeedback(1, `Please say "private", "EV", or "commercial"`);
            }
            break;

        case 2:
            let phone = transcript.replace(/\D/g, '');
            if (phone.length === 10) {
                phone = phone.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
            } else if (phone.length === 11 && phone.startsWith('1')) {
                phone = phone.substring(1);
                phone = phone.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
            }
            phoneNumber.value = phone;
            updateFeedback(2, `Phone number set to: ${phone}`);
            break;

        case 3:
            let processedEmail = processEmail(transcript);
            if (isValidEmail(processedEmail)) {
                emailInput.value = processedEmail;
                updateFeedback(3, `Email set to: ${processedEmail}`);
            } else {
                updateFeedback(3, `Please provide a valid email address. Try saying "john dot doe at gmail dot com"`);
            }
            break;

        case 4:
            if (transcript.includes('1') || transcript.includes('one') || transcript.includes('first')) {
                selectAvailableSlot('slot1');
            } else if (transcript.includes('2') || transcript.includes('two') || transcript.includes('second')) {
                selectAvailableSlot('slot2');
            } else if (transcript.includes('3') || transcript.includes('three') || transcript.includes('third')) {
                selectAvailableSlot('slot3');
            } else if (transcript.includes('4') || transcript.includes('four') || transcript.includes('fourth')) {
                selectAvailableSlot('slot4');
            } else {
                updateFeedback(4, `Please say "slot 1", "slot 2", "slot 3", or "slot 4"`);
            }
            break;

        case 5:
            timeDuration.value = processTimeDuration(transcript);
            updateFeedback(5, `Duration set to: ${timeDuration.value}`);
            break;
    }
}

// Select car type option
function selectCarTypeOption(carType) {
    carTypeOptions.querySelectorAll('.option').forEach(opt => {
        opt.classList.remove('selected');
    });

    const option = Array.from(carTypeOptions.querySelectorAll('.option')).find(
        opt => opt.dataset.value === carType
    );

    if (option) {
        option.classList.add('selected');
        selectedCarType = carType;
        updateFeedback(1, `Selected: ${option.textContent}`);
    }
}

// Select an available slot
function selectAvailableSlot(slotId) {
    if (parkingData[slotId] && (parkingData[slotId].status === 'available' || parkingData[slotId].status === 'unknown')) {
        slotOptions.querySelectorAll('.option').forEach(opt => {
            opt.classList.remove('selected');
        });

        const option = Array.from(slotOptions.querySelectorAll('.option')).find(
            opt => opt.dataset.value === slotId
        );

        if (option) {
            option.classList.add('selected');
            selectedSlot = slotId;
            updateFeedback(4, `Selected: ${option.textContent}`);
        }
    } else {
        updateFeedback(4, `Slot ${slotId.charAt(slotId.length-1)} is not available. Please choose another slot.`);
    }
}

// Process email from speech
function processEmail(transcript) {
    let email = transcript
        .replace(/\s+(at|add|app)\s+/gi, '@')
        .replace(/\s+(dot|point|period)\s+/gi, '.')
        .replace(/\s+(underscore|underline|under)\s+/gi, '_')
        .replace(/\s+(dash|hyphen|minus)\s+/gi, '-')
        .replace(/\s+/g, '')
        .toLowerCase();

    if (!email.includes('@')) {
        const atIndex = transcript.toLowerCase().indexOf(' at ');
        if (atIndex !== -1) {
            const beforeAt = transcript.substring(0, atIndex).replace(/\s+/g, '');
            const afterAt = transcript.substring(atIndex + 4).replace(/\s+/g, '');
            email = beforeAt + '@' + afterAt;
        }
    }

    return email;
}

// Validate email format
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Process time duration from speech
function processTimeDuration(transcript) {
    let duration = transcript
        .replace(/\b(\d+)\s*(\s?pm|am)\s*to\s*(\d+)\s*(\s?pm|am)\b/gi, '$1$2 to $3$4')
        .replace(/\b(\d+)\s*(\s?pm|am)\s*until\s*(\d+)\s*(\s?pm|am)\b/gi, '$1$2 until $3$4')
        .replace(/\b(\d+)\s*(\s?pm|am)\s*till\s*(\d+)\s*(\s?pm|am)\b/gi, '$1$2 till $3$4')
        .replace(/\b(\d+)\s*hours?\b/gi, '$1 hours')
        .replace(/\b(\d+)\s*hrs?\b/gi, '$1 hours');

    duration = duration.replace(/\b(am|pm)\b/gi, function(match) {
        return match.toUpperCase();
    });

    return duration;
}

// Update feedback message
function updateFeedback(stepIndex, message) {
    feedbacks[stepIndex].textContent = message;
}

// Show a specific step
function showStep(stepIndex) {
    steps.forEach((step, index) => {
        if (index === stepIndex) {
            step.classList.add('active');
        } else {
            step.classList.remove('active');
        }
    });

    prevBtn.style.display = stepIndex === 0 ? 'none' : 'block';

    if (stepIndex === steps.length - 1) {
        nextBtn.style.display = 'none';
        bookBtn.style.display = 'block';
    } else {
        nextBtn.style.display = 'block';
        bookBtn.style.display = 'none';
    }
}

// Go to the next step
function goToNextStep() {
    if (currentStep < steps.length - 1) {
        currentStep++;
        showStep(currentStep);
    }
}

// Go to the previous step
function goToPreviousStep() {
    if (currentStep > 0) {
        currentStep--;
        showStep(currentStep);
    }
}

// Confirm booking with email integration
function confirmBooking() {
    if (!carNumber.value) {
        alert('Please enter your car number');
        currentStep = 0;
        showStep(currentStep);
        return;
    }

    if (!selectedCarType) {
        alert('Please select your car type');
        currentStep = 1;
        showStep(currentStep);
        return;
    }

    if (!phoneNumber.value) {
        alert('Please enter your phone number');
        currentStep = 2;
        showStep(currentStep);
        return;
    }

    if (!emailInput.value || !isValidEmail(emailInput.value)) {
        alert('Please enter a valid email address');
        currentStep = 3;
        showStep(currentStep);
        return;
    }

    if (!selectedSlot) {
        alert('Please select a parking slot');
        currentStep = 4;
        showStep(currentStep);
        return;
    }

    if (!timeDuration.value) {
        alert('Please enter parking duration');
        currentStep = 5;
        showStep(currentStep);
        return;
    }

    const bookingId = 'PARK' + Math.floor(100000 + Math.random() * 900000);

    confirmCarNumber.textContent = carNumber.value;
    confirmCarType.textContent = selectedCarType.charAt(0).toUpperCase() + selectedCarType.slice(1);
    confirmPhone.textContent = phoneNumber.value;
    confirmEmail.textContent = emailInput.value;
    confirmSlot.textContent = selectedSlot.charAt(0).toUpperCase() + selectedSlot.slice(1);
    confirmDuration.textContent = timeDuration.value;
    confirmBookingId.textContent = bookingId;

    emailNotifier.registerCustomer(emailInput.value, phoneNumber.value);

    const bookingData = {
        email: emailInput.value,
        name: 'Customer',
        carNumber: carNumber.value,
        carType: selectedCarType,
        slot: selectedSlot,
        duration: timeDuration.value,
        bookingId: bookingId
    };

    emailNotifier.sendBookingConfirmation(bookingData);

    updateFirebaseWithBooking(selectedSlot, timeDuration.value, bookingId, carNumber.value, selectedCarType, phoneNumber.value, emailInput.value);

    document.querySelector('.booking-form').style.display = 'none';
    confirmation.classList.add('active');
}

// Reset form for new booking
function resetForm() {
    carNumber.value = '';
    phoneNumber.value = '';
    emailInput.value = '';
    timeDuration.value = '';

    selectedCarType = '';
    selectedSlot = '';

    document.querySelectorAll('.option').forEach(option => {
        option.classList.remove('selected');
    });

    feedbacks.forEach((feedback, index) => {
        if (index === 0) {
            feedback.textContent = 'Click the microphone and speak your car number';
        } else if (index === 1) {
            feedback.textContent = 'Click the microphone and say "private", "EV", or "commercial"';
        } else if (index === 2) {
            feedback.textContent = 'Click the microphone and speak your phone number';
        } else if (index === 3) {
            feedback.textContent = 'Click the microphone and speak your email address';
        } else if (index === 4) {
            feedback.textContent = 'Click the microphone and say a slot number (1-4)';
        } else if (index === 5) {
            feedback.textContent = 'Click the microphone and speak your parking duration (e.g., "2 PM to 3 PM")';
        }
    });

    currentStep = 0;
    showStep(currentStep);

    document.querySelector('.booking-form').style.display = 'block';
    confirmation.classList.remove('active');

    if (emailStatusDisplay) {
        emailStatusDisplay.style.display = 'none';
    }
}

// Initialize the app when the page loads
window.addEventListener('DOMContentLoaded', initApp);

// Make parkingData globally available
window.parkingData = parkingData;